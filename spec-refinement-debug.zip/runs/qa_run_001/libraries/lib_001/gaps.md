## Open Gaps

## Integrated Gaps

## Deferred Gaps

## Rejected Gaps
