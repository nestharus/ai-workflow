# Architecture Mapping

## Architecture: arch_001

A two-layer monolith where lib_001 forms the request-handling layer and lib_002 forms the persistence layer. All code deploys as a single unit with strict layer boundaries enforced at the module level. Requests flow top-down: intake → validation → routing → persistence.

## Component Mappings

### Component: Request Layer (lib_001)

**Responsibilities**: Accept inbound requests and enforce the 200ms SLA; Validate all inputs before forwarding; Route validated requests to the persistence layer

**Libraries**:
- lib_001: Handles inbound request processing, input validation, and routing to downstream consumers. [lib_001::charter.md]

### Component: Persistence Layer (lib_002)

**Responsibilities**: Store records durably; Provide ID-based record retrieval; Expose internal APIs consumed by the request layer

**Libraries**:
- lib_002: Provides durable data persistence and retrieval APIs for consuming libraries such as lib_001 [file_002::INTRO] [file_002::REQS]

## Cross-Component Dependencies

- Request Layer (lib_001) -> Persistence Layer (lib_002): Uses Beta APIs for durable storage and ID-based retrieval [file_001::DEPS] [file_002::DEPS]

## Unmapped Libraries

- None
