# Architecture Candidate: arch_004

## Pattern
Hexagonal (Ports and Adapters)

## Description
lib_001 forms the application core with input ports (request intake) and output ports (persistence). lib_002 implements the persistence output port as an adapter. The architecture enforces dependency inversion: the core defines interfaces, adapters implement them.

## Components
- Application Core (lib_001): Define input port interfaces for request intake and validation; Define output port interfaces for persistence operations (store, retrieve by ID); Implement request validation and routing logic; Enforce 200ms SLA at the orchestration level
- Persistence Adapter (lib_002): Implement the persistence output port defined by the core; Guarantee data durability behind the port interface; Provide ID-based retrieval through the port contract
- Inbound Adapter: Translate external protocol (HTTP, gRPC, CLI) into input port calls; Handle protocol-specific concerns (headers, status codes)

## Communication
In-process via port interfaces. The core calls output ports through dependency-injected adapters. No direct coupling between lib_001 business logic and lib_002 implementation details.

## Deployment
Single deployable unit. The adapter can be swapped at startup (e.g., in-memory adapter for tests, durable adapter for production) without changing the core.

## Tradeoffs
### Advantages
- Highest testability: the core can be tested with in-memory adapters, achieving sub-millisecond test execution with zero I/O
- Adapter swappability: persistence backend can change (e.g., Postgres to DynamoDB) without modifying lib_001
- Dependency direction is explicit and enforced: lib_002 depends on lib_001's port interface, not the reverse

### Disadvantages
- Additional abstraction layer: port interfaces add 5-15 lines of code per operation compared to direct calls
- Indirection cost: developers must navigate through port interfaces to trace call paths, increasing onboarding time by an estimated 10-20%
- For only two libraries, the port/adapter ceremony may be disproportionate to the complexity being managed

## Citations
- [lib_001::charter.md] — 'delegates to lib_002' is formalized as an output port, making the delegation contract explicit and testable
- [lib_002::charter.md] — 'exposes APIs consumed by other libraries' maps to implementing a port interface defined by the consumer
- [lib_002::charter.md] — 'does not initiate requests' confirms adapter role: it is invoked through a port, never calls into the core
- [lib_001::charter.md] — 200ms SLA enforcement stays in the core, independent of which adapter is plugged in
