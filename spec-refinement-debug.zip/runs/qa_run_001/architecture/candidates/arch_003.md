# Architecture Candidate: arch_003

## Pattern
Modular Monolith with Event Bus

## Description
A single deployment unit containing both libraries as isolated modules. Synchronous calls handle reads (ID lookups), while writes (record storage) are dispatched through an in-process event bus for decoupling. Each module enforces its boundary through explicit public APIs.

## Components
- Request Module (lib_001): Accept and validate inbound requests; Publish 'store record' events onto the internal event bus for writes; Call lib_002's query API directly for synchronous reads; Enforce 200ms SLA
- Persistence Module (lib_002): Subscribe to 'store record' events and persist data durably; Expose a synchronous query API for ID-based retrieval; Guarantee durability for all consumed events
- Internal Event Bus: Route events between modules within the same process; Provide at-least-once delivery semantics for write events; Enable future extraction of modules into separate services

## Communication
Hybrid: synchronous in-process calls for reads (latency-sensitive), asynchronous in-process event dispatch for writes (decoupled). The event bus is an in-process queue, not a network broker.

## Deployment
Single deployable artifact. Modules are logically separated but physically co-located. The event bus abstraction makes it possible to later replace in-process dispatch with a network broker if the system splits into services.

## Tradeoffs
### Advantages
- Stronger module isolation than arch_001: modules communicate through explicit APIs and events, not direct imports
- Write path is decoupled: lib_001 does not block on lib_002's write acknowledgment, freeing latency budget
- Migration path: modules can be extracted into separate services later by replacing the in-process bus with a network broker

### Disadvantages
- Eventual consistency on writes: lib_001 returns success before lib_002 confirms persistence, which may violate durability expectations if the process crashes between event dispatch and persistence (data loss window of up to 1 event in-flight)
- Added complexity of event contracts and at-least-once delivery logic compared to direct function calls
- Debugging is harder: write failures surface asynchronously rather than in the request call stack

## Citations
- [lib_001::charter.md] — 200ms SLA drives synchronous reads; in-process event dispatch keeps write latency under 1ms
- [lib_001::charter.md] — 'validates inputs before any downstream processing' remains enforced before event publication
- [lib_002::charter.md] — 'does not initiate requests' aligns with a subscriber/responder role on the event bus
- [lib_002::charter.md] — durability guarantee requires at-least-once delivery from the event bus to the persistence module
