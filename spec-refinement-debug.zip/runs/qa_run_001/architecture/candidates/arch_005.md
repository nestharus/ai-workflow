# Architecture Candidate: arch_005

## Pattern
CQRS (Command Query Responsibility Segregation)

## Description
Separates the write path (commands: store records) from the read path (queries: retrieve by ID). lib_001 splits into a command handler and a query handler. lib_002 provides separate optimized stores for writes and reads.

## Components
- Command Handler (lib_001 write path): Validate and accept write requests; Route validated commands to the write store; Enforce 200ms SLA on command responses
- Query Handler (lib_001 read path): Accept read requests (ID-based lookup); Route queries to the read-optimized store; Enforce 200ms SLA on query responses
- Write Store (lib_002 command side): Persist records durably with write-optimized storage; Publish change events to synchronize the read store
- Read Store (lib_002 query side): Maintain a read-optimized projection of stored records; Support fast ID-based lookups

## Communication
Commands and queries follow separate in-process paths. Write store publishes internal events to update the read store projection. Both paths use in-process calls to keep latency within the 200ms budget.

## Deployment
Single deployment unit with logically separated read/write paths. Can be split into separate services later if read and write loads diverge significantly.

## Tradeoffs
### Advantages
- Read and write paths can be optimized independently: read store can use denormalized data for sub-10ms lookups
- Write throughput is not constrained by read indexing overhead
- Clear separation of concerns aligns with lib_002's explicit split between storage and retrieval responsibilities

### Disadvantages
- Significant over-engineering for the current scale: at 100 req/s, a single store handles both reads and writes without contention
- Eventual consistency between write and read stores introduces a synchronization lag (typically 1-50ms) where a just-written record may not be retrievable
- Doubles the storage surface area and the number of data models to maintain, increasing code volume by an estimated 40-60% compared to a unified store

## Citations
- [lib_001::charter.md] — 100 req/s throughput may include mixed read/write workloads that benefit from separate optimization
- [lib_002::charter.md] — 'record storage' and 'record retrieval' are explicitly listed as separate responsibilities, mapping naturally to CQRS split
- [lib_002::charter.md] — durability guarantee applies to the write store; the read store can use eventually-consistent projections
- [lib_001::charter.md] — 200ms SLA can be met independently on each path with path-specific optimization
