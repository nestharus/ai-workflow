# Architecture Candidate: arch_002

## Pattern
Client-Server (Two-Service Split)

## Description
lib_001 deploys as a standalone request-processing service and lib_002 deploys as a separate persistence service. Communication crosses a network boundary via synchronous HTTP or gRPC calls.

## Components
- Request Service (lib_001): Accept inbound requests at up to 100 req/s; Validate inputs before any downstream call; Call the persistence service for storage and retrieval; Enforce the 200ms end-to-end SLA including network round-trip to lib_002
- Persistence Service (lib_002): Expose HTTP/gRPC endpoints for record storage and ID-based retrieval; Guarantee data durability; Scale independently based on storage I/O load

## Communication
Synchronous RPC (HTTP/2 or gRPC). lib_001 sends requests to lib_002 over the network. Retry and circuit-breaker policies protect against transient failures. Typical intra-datacenter round-trip adds 1-5ms per call.

## Deployment
Two independently deployable services. Each has its own container, scaling policy, and health checks. Requires a service registry or DNS-based discovery.

## Tradeoffs
### Advantages
- Independent scaling: lib_002 can scale storage I/O separately from lib_001's request throughput
- Fault isolation: a crash in the persistence service does not kill the request service (it can return 503 gracefully)
- Independent deployment: lib_002 can be updated without redeploying lib_001

### Disadvantages
- Network latency consumes 1-5ms of the 200ms SLA budget per call, reducing headroom by 0.5-2.5%
- Operational complexity: two services require service discovery, health checks, and coordinated monitoring
- Testing requires either network mocking or a running instance of both services

## Citations
- [lib_001::charter.md] — 'delegates to lib_002' can be realized as a remote call if the latency budget permits
- [lib_001::charter.md] — 200ms SLA leaves approximately 195ms of budget after a 1-5ms network hop, which is feasible for simple CRUD persistence
- [lib_002::charter.md] — 'exposes APIs consumed by other libraries' maps directly to a service contract
- [lib_002::charter.md] — 'does not initiate requests' confirms it operates as a server only
