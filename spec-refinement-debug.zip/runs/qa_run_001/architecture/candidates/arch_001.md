# Architecture Candidate: arch_001

## Pattern
Layered Monolith

## Description
A two-layer monolith where lib_001 forms the request-handling layer and lib_002 forms the persistence layer. All code deploys as a single unit with strict layer boundaries enforced at the module level. Requests flow top-down: intake → validation → routing → persistence.

## Components
- Request Layer (lib_001): Accept inbound requests and enforce the 200ms SLA; Validate all inputs before forwarding; Route validated requests to the persistence layer
- Persistence Layer (lib_002): Store records durably; Provide ID-based record retrieval; Expose internal APIs consumed by the request layer

## Communication
In-process function calls. lib_001 imports lib_002's API module directly. No network boundary between layers, minimizing latency overhead.

## Deployment
Single deployable unit. Both layers share a process and a deployment artifact. Scaling is vertical or via process replication behind a load balancer.

## Tradeoffs
### Advantages
- Lowest latency path: in-process calls add < 1ms overhead, leaving the full 200ms budget for business logic and I/O
- Simplest deployment: one artifact, one process, no service discovery
- Easiest to test: integration tests run in a single process without network mocking

### Disadvantages
- Scaling is coarse-grained: the request layer and persistence layer must scale together even if only one is the bottleneck
- A bug in lib_002 can crash the lib_001 process, reducing fault isolation
- Adding a third library later requires redeployment of the entire monolith

## Citations
- [lib_001::charter.md] — 200ms SLA enforcement is easiest to guarantee with in-process calls that avoid network serialization overhead
- [lib_001::charter.md] — 'delegates to lib_002' implies a direct dependency, naturally modeled as a layer boundary
- [lib_002::charter.md] — 'does not initiate requests' confirms it is a passive lower layer
- [lib_002::charter.md] — 'exposes APIs consumed by other libraries' maps to an internal module interface
