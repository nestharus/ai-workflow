# Selected Architecture: arch_001

## Rationale
arch_001 best fits the stated responsibilities and constraints with the least unjustified complexity. It cleanly maps lib_001’s required request handling and pre-routing validation [file_001::REQS] to a direct, in-process delegation to Beta (lib_002) for durable record storage and ID-based retrieval [file_001::DEPS] [file_002::REQS]. Because lib_001 must respond within 200ms [file_001::CONSTRAINTS] while sustaining up to 100 req/s [file_001::REQS], avoiding a network boundary reduces latency variability and preserves budget for actual persistence I/O. Most importantly, the layered in-process call supports a synchronous write path where lib_001 can only acknowledge success once lib_002 has durably committed the record, satisfying the durability constraint for data stored via Beta [file_002::CONSTRAINTS] and lib_002’s reliability requirement [file_002::REQS]. Finally, the dependency direction in the specs (lib_001 consumes Beta, and Beta is the persistence layer for lib_001) [file_001::DEPS] [file_002::DEPS] is naturally expressed as a top-down layered monolith without introducing extra service contracts or consistency mechanisms.

## Implementation Risks
- {'risk': 'Persistence latency can dominate the 200ms end-to-end budget under load spikes or slow storage I/O.', 'mitigation': 'Set explicit per-operation timeouts; monitor p95/p99 latency; keep hot paths indexed; use connection pooling; apply backpressure (reject/queue) when saturation is detected; consider caching read-mostly lookups if consistent with durability semantics.'}
- {'risk': 'Fault isolation is weak: a crash or fatal bug in lib_002 can take down the whole process, impacting availability of lib_001.', 'mitigation': 'Harden error handling boundaries (no uncaught exceptions across the layer boundary); run multiple stateless replicas behind a load balancer; add health checks and rapid restart; if this becomes a frequent failure mode, evolve to a two-service split with clear SLAs.'}
- {'risk': 'Layer boundary erosion (cyclic imports / cross-layer access) can accumulate quickly in a monolith, undermining maintainability.', 'mitigation': 'Enforce a strict public API for lib_002; prohibit direct access to internals via lint/static checks; keep DTOs and interfaces stable and narrow; maintain a clear dependency graph.'}
- {'risk': 'Durability semantics can be accidentally weakened (e.g., acknowledging before fsync/commit/replication thresholds).', 'mitigation': 'Define “durable” precisely in lib_002 (commit conditions); ensure the store API only returns success after the durability condition is met; add tests that validate durability guarantees under restart scenarios.'}
- {'risk': 'Coarse-grained scaling: if persistence becomes the bottleneck, scaling lib_001 and lib_002 together can be inefficient.', 'mitigation': 'Scale horizontally with whole-process replicas initially; optimize persistence hotspots; once the bottleneck is clear and persistent, split lib_002 into its own service (arch_002-style) to scale independently.'}

## Evolution Notes
- If independent scaling or stronger fault isolation becomes necessary, extract lib_002 behind its existing internal API into a separate persistence service (evolution toward arch_002) while keeping lib_001’s validation-first behavior intact [file_001::REQS].
- If test isolation and backend swappability become higher priority, introduce explicit interfaces at the lib_001→lib_002 boundary inside the monolith (partial move toward arch_004) without changing the core requirement that lib_001 uses Beta for durable storage/retrieval [file_001::DEPS] [file_002::DEPS].
- If asynchronous write handling is later required for throughput, do not acknowledge writes before durability is ensured; adopt a durable queue/outbox pattern so “success” still implies Beta-durable storage [file_002::CONSTRAINTS].
- Only consider CQRS-style separation (arch_005) if there is a demonstrated read/write scaling mismatch and explicit consistency expectations are documented; otherwise keep a single durable store to preserve simplicity and correctness.

## Selected Candidate
# Architecture Candidate: arch_001

## Pattern
Layered Monolith

## Description
A two-layer monolith where lib_001 forms the request-handling layer and lib_002 forms the persistence layer. All code deploys as a single unit with strict layer boundaries enforced at the module level. Requests flow top-down: intake → validation → routing → persistence.

## Components
- Request Layer (lib_001): Accept inbound requests and enforce the 200ms SLA; Validate all inputs before forwarding; Route validated requests to the persistence layer
- Persistence Layer (lib_002): Store records durably; Provide ID-based record retrieval; Expose internal APIs consumed by the request layer

## Communication
In-process function calls. lib_001 imports lib_002's API module directly. No network boundary between layers, minimizing latency overhead.

## Deployment
Single deployable unit. Both layers share a process and a deployment artifact. Scaling is vertical or via process replication behind a load balancer.

## Tradeoffs
### Advantages
- Lowest latency path: in-process calls add < 1ms overhead, leaving the full 200ms budget for business logic and I/O
- Simplest deployment: one artifact, one process, no service discovery
- Easiest to test: integration tests run in a single process without network mocking

### Disadvantages
- Scaling is coarse-grained: the request layer and persistence layer must scale together even if only one is the bottleneck
- A bug in lib_002 can crash the lib_001 process, reducing fault isolation
- Adding a third library later requires redeployment of the entire monolith

## Citations
- [lib_001::charter.md] — 200ms SLA enforcement is easiest to guarantee with in-process calls that avoid network serialization overhead
- [lib_001::charter.md] — 'delegates to lib_002' implies a direct dependency, naturally modeled as a layer boundary
- [lib_002::charter.md] — 'does not initiate requests' confirms it is a passive lower layer
- [lib_002::charter.md] — 'exposes APIs consumed by other libraries' maps to an internal module interface
